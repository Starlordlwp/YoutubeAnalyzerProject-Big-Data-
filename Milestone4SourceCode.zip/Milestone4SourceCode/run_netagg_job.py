from __future__ import annotations

import argparse
import json
import os

import pandas as pd
from pyspark.sql import functions as F

import YoutubeNetworkAgg_Final as netagg  # same module used in guiV4.py


# ---------------------------------------------------------------------------
# Helpers to compute the same stats as guiV4's "Network statistics" tab
# ---------------------------------------------------------------------------

def compute_degree_stats(graph):
    """
    Compute degree statistics from a GraphFrame.

    Returns a dict with four keys:
      - out_degree_distribution
      - in_degree_distribution
      - top_by_out_degree
      - top_by_in_degree

    Each value is a list[dict], ready to be JSON-serialized.
    """
    out_deg = graph.outDegrees
    in_deg = graph.inDegrees

    out_dist = (
        out_deg.groupBy("outDegree")
        .count()
        .orderBy("outDegree")
        .limit(20)
    )
    in_dist = (
        in_deg.groupBy("inDegree")
        .count()
        .orderBy("inDegree")
        .limit(20)
    )

    top_out = (
        graph.vertices
        .join(out_deg, "id", "left")
        .fillna({"outDegree": 0})
        .orderBy(F.desc("outDegree"))
        .select("id", "category", "views", "outDegree")
        .limit(20)
    )
    top_in = (
        graph.vertices
        .join(in_deg, "id", "left")
        .fillna({"inDegree": 0})
        .orderBy(F.desc("inDegree"))
        .select("id", "category", "views", "inDegree")
        .limit(20)
    )

    out_dist_pd = out_dist.toPandas()
    in_dist_pd = in_dist.toPandas()
    top_out_pd = top_out.toPandas()
    top_in_pd = top_in.toPandas()

    return {
        "out_degree_distribution": out_dist_pd.to_dict(orient="records"),
        "in_degree_distribution": in_dist_pd.to_dict(orient="records"),
        "top_by_out_degree": top_out_pd.to_dict(orient="records"),
        "top_by_in_degree": top_in_pd.to_dict(orient="records"),
    }


def compute_category_stats(df):
    """
    Aggregated statistics by category.

    Returns list[dict] with columns:
      category, num_videos, avg_views, max_views, avg_length, avg_rating
    """
    stats = (
        df.groupBy("category")
        .agg(
            F.count("*").alias("num_videos"),
            F.avg("views").alias("avg_views"),
            F.max("views").alias("max_views"),
            F.avg("length").alias("avg_length"),
            F.avg("rate").alias("avg_rating"),
        )
        .orderBy(F.desc("num_videos"))
        .limit(50)
    )

    stats_pd = stats.toPandas()
    # Make sure everything is JSON-serializable
    return stats_pd.to_dict(orient="records")


def compute_video_size_buckets(df):
    """
    Bucket videos by length and compute counts / view stats.

    Buckets:
      - short (< 4 min)
      - medium (4–20 min)
      - long (>= 20 min)

    Returns list[dict] with columns:
      length_bucket, num_videos, avg_views, max_views
    """
    bucketed = (
        df.withColumn(
            "length_bucket",
            F.when(F.col("length") < 240, "short (<4 min)")
             .when(F.col("length") < 1200, "medium (4–20 min)")
             .otherwise("long (>=20 min)")
        )
        .groupBy("length_bucket")
        .agg(
            F.count("*").alias("num_videos"),
            F.avg("views").alias("avg_views"),
            F.max("views").alias("max_views"),
        )
        .orderBy("length_bucket")
    )

    bucketed_pd = bucketed.toPandas()
    return bucketed_pd.to_dict(orient="records")


def compute_view_count_stats(df):
    """
    Global view statistics + bucketed counts.

    Returns a dict:
      {
        "global_stats": { ... single row ... },
        "view_buckets": [ ... list of bucket rows ... ]
      }
    """
    stats = df.agg(
        F.count("*").alias("num_videos"),
        F.avg("views").alias("avg_views"),
        F.stddev("views").alias("stddev_views"),
        F.expr("percentile_approx(views, 0.5)").alias("median_views"),
        F.expr("percentile_approx(views, 0.9)").alias("p90_views"),
        F.max("views").alias("max_views"),
    )

    buckets = (
        df.withColumn(
            "views_bucket",
            F.when(F.col("views") < 1_000, "<1k")
             .when(F.col("views") < 10_000, "1k–10k")
             .when(F.col("views") < 100_000, "10k–100k")
             .when(F.col("views") < 1_000_000, "100k–1M")
             .otherwise(">=1M")
        )
        .groupBy("views_bucket")
        .count()
        .orderBy("views_bucket")
    )

    stats_pd = stats.toPandas()
    buckets_pd = buckets.toPandas()

    # stats_pd should have exactly one row
    global_stats = {}
    if not stats_pd.empty:
        global_stats = stats_pd.iloc[0].to_dict()

    return buckets_pd.to_dict(orient="records")




def main():
  

    degree_path = "degreestat_cache.json"
    category_path = "categorystats_cache.json"
    size_path = "sizestats_cache.json"
    view_path = "viewstats_cache.json"

    spark = None
    try:
        print("Initializing Spark session and loading videos DataFrame...")
        spark = netagg.build_spark_session()
        df = netagg.load_videos_df(spark)

        print("Building GraphFrame...")
        graph = netagg.build_graph(df)

        # ---- Degree statistics ----
        print("Computing degree statistics...")
        degree_stats_dict = compute_degree_stats(graph)
        with open(degree_path, "w", encoding="utf-8") as f:
            json.dump(degree_stats_dict, f, indent=4, ensure_ascii=False)
        print(f"Degree statistics written to {degree_path}")

        # ---- Category statistics ----
        print("Computing category statistics...")
        category_stats_list = compute_category_stats(df)
        with open(category_path, "w", encoding="utf-8") as f:
            json.dump(category_stats_list, f, indent=4, ensure_ascii=False)
        print(f"Category statistics written to {category_path}")

        # ---- Video size buckets ----
        print("Computing video size buckets...")
        size_buckets_list = compute_video_size_buckets(df)
        with open(size_path, "w", encoding="utf-8") as f:
            json.dump(size_buckets_list, f, indent=4, ensure_ascii=False)
        print(f"Video size buckets written to {size_path}")

        # ---- View count statistics ----
        print("Computing view count statistics...")
        view_stats_dict = compute_view_count_stats(df)
        with open(view_path, "w", encoding="utf-8") as f:
            json.dump(view_stats_dict, f, indent=4, ensure_ascii=False)
        print(f"View count statistics written to {view_path}")

        print("run_networkagg_job.py completed successfully.")

    except Exception as e:
        # Keep this simple/robust for subprocess usage
        print(f"Error in run_netagg_job.py: {e}")
        raise

    finally:
        if spark is not None:
            try:
                spark.stop()
            except Exception:
                pass


if __name__ == "__main__":
    main()


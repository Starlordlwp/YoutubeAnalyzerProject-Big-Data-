To run this program first make sure that you are in the directory that contains the code included in this .zip file. Then run the command "streamlit run guiV5.py". 
All of the necessarry caches are included with the source code zip so in phase 1 you can select use existing cache for all three options. If you are conected to the 
415_YoutubeGroupDB you can access all of the features of this app but without being connected to the database you can run the page rank, user recs and network stats 
operations.  

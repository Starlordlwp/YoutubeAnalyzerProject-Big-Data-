from pyspark.sql import SparkSession
from pyspark.ml.recommendation import ALS
from pyspark.sql.functions import col
from pyspark.sql.types import IntegerType
from pyspark.sql.types import StructType, StructField
from pyspark.sql import DataFrame
from pyspark.sql.functions import col, explode, collect_list
from pyspark.sql.functions import first

ALS_CACHE_PATH = "als_recs_cache.json"

def strip_metadata(df, cols):
    """
    Return a new DataFrame where the given columns keep only
    (name, dataType, nullable) and drop heavy metadata
    (like StringIndexer label arrays).
    """
    new_schema = StructType([
        StructField(f.name, f.dataType, f.nullable) if f.name in cols else f
        for f in df.schema.fields
    ])
    return df.sql_ctx.createDataFrame(df.rdd, new_schema)


def main():

    spark = (
    SparkSession.builder
        .appName("YouTubeVideoRecommendation")
        .config(
            "spark.jars.packages",
            "org.mongodb.spark:mongo-spark-connector_2.12:10.5.0",
        )
        .config("spark.mongodb.connection.uri", "mongodb://localhost:27017")
        .config("spark.driver.memory", "16g")
        .config("spark.executor.memory", "16g")
        .config("spark.driver.maxResultSize", "8g")
        # >>> ADD THESE LINES <<<
        .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
        .config("spark.kryoserializer.buffer", "64m")      # initial buffer
        .config("spark.kryoserializer.buffer.max", "512m") # max per-object buffer
        # <<< END ADDED LINES <<<
        .getOrCreate()
    )
    

    # 2. Load your EXISTING data from MongoDB
    # ----------------------------------------------------------
    videos_df = spark.read.format("mongodb").option("database", "415_YoutubeGroupDB").option("collection", "videos").load()

    print("Loaded videos from MongoDB.")
    videos_df = videos_df.select("_id", "uploader", "rate").na.drop(subset=["uploader", "rate"])
    videos_df.printSchema()
    
    videos_df = videos_df.sample(fraction=0.10, seed=42).cache()
    print("Base sampled rows:", videos_df.count())
    
    
   #3 prep dataset numeric IDs for ALS
    from pyspark.ml.feature import StringIndexer

    user_indexer = StringIndexer(inputCol="uploader", outputCol="userId")
    video_indexer = StringIndexer(inputCol="_id", outputCol="videoId")

    videos_indexed = user_indexer.fit(videos_df).transform(videos_df)
    videos_indexed = video_indexer.fit(videos_indexed).transform(videos_indexed)
    
    
    # ALS expects "rating" column;use 'rate' from dataset
    als_df = videos_indexed.select(
        col("userId").cast(IntegerType()),
        col("videoId").cast(IntegerType()),
        col("rate").alias("rating")
    ).na.drop()
    
    als_df = strip_metadata(als_df, ["userId", "videoId", "rating"]) #Strip heavy StringIndexer metadata before ALS
    
    print("Prepared data for ALS.")
    als_df.show(5, truncate=False)

    # ----------------------------------------------------------
    # 4. Train ALS model
    # ----------------------------------------------------------
    als = ALS(
        maxIter=10,
        regParam=0.1,
        userCol="userId",
        itemCol="videoId",
        ratingCol="rating",
        coldStartStrategy="drop"
    )

    model = als.fit(als_df)
    print("ALS model trained.\n")

    # ----------------------------------------------------------
    # 5. Make recommendations for all users
    # ----------------------------------------------------------
    #
    # user_recs = model.recommendForAllUsers(5)  # top 5 video recommendations per uploader

    user_subset = als_df.select("userId").distinct().limit(500)

    user_recs = model.recommendForUserSubset(user_subset, 5)
    print("Sample recommendations:")
    
    user_recs.show(truncate=False)

    print(f"Saving recommendations to {ALS_CACHE_PATH}...")
    
    # Dimension table of videoId -> _id
    video_dim = (
        videos_indexed
        .select("videoId", "_id")
        .dropDuplicates(["videoId"])
    )
    
    user_dim = (
    videos_indexed
    .select("userId", "uploader")
    .dropDuplicates(["userId"])
    )

    # Explode the recommendations array into one row per (userId, videoId)
    exploded = (
        user_recs
        .select(
            col("userId"),
            explode("recommendations").alias("rec")
        )
        .select(
            col("userId"),
            col("rec.videoId").alias("videoId")
        )
    )

    # Join to get the original _id for each recommended video
    joined_videos = exploded.join(video_dim, on="videoId", how="left")
    joined_full = joined_videos.join(user_dim, on="userId", how="left")

    # Group back to (userId, [list of _id strings])
    final_recs_df = joined_full.groupBy("userId").agg(
    first("uploader").alias("uploader"),
    collect_list("_id").alias("recommendations")
)

    
    
    
    # Convert recommendations to Pandas DataFrame for easy JSON export
    user_recs_pandas = final_recs_df.toPandas()
    
    
    
    # Save as JSON
    user_recs_pandas.to_json(ALS_CACHE_PATH, orient="records")
    
    print("Save complete.")

    spark.stop()


if __name__ == "__main__":
    main()

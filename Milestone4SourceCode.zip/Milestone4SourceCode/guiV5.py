from __future__ import annotations

import json
import os
import subprocess
import sys
from functools import reduce
from typing import Callable, Dict, Iterable, List, Literal, Tuple

from pymongo import MongoClient
from pyspark.sql import functions as F
from pyspark.sql import types as T  # not strictly required but kept from test_.py

import numpy as np
import pandas as pd
import streamlit as st

st.set_page_config(page_title="EverCougs YouTube Analyzer", layout="wide")

# === import your network aggregation module (must be in same folder) ===
import YoutubeNetworkAgg_Final as netagg  # from test_.py

# =============================================================================
# non-operation-specific helpers
# =============================================================================

def load_json(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def write_json(path: str, data: dict) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def open_video(video_id: str) -> None:
    url = f"https://www.youtube.com/watch?v={video_id}"
    st.video(url)
    st.markdown(f"[Open in a new tab]({url})")


def get_mongo_collection():
    try:
        client = MongoClient("mongodb://localhost:27017/", serverSelectionTimeoutMS=5000)
        # Test connection
        client.server_info()
        db = client["415_YoutubeGroupDB"]
        collection = db["videos"]
        return collection
    except Exception as e:
        st.error(f"Failed to connect to MongoDB: {e}")
        return None

# =============================================================================
# phase 1 operation helpers (precache expensive jobs)
# =============================================================================

PAGERANK_CACHE_PATH = "pagerank_cache.json"
ALS_CACHE_PATH = "als_recs_cache.json"
DEGREE_CACHE_PATH = "degreestat_cache.json"
CATEGORY_CACHE_PATH = "categorystats_cache.json"
SIZE_CACHE_PATH = "sizestats_cache.json"
VIEW_CACHE_PATH = "viewstats_cache.json"

def load_pr_cache() -> pd.DataFrame | None:
    if not os.path.exists(PAGERANK_CACHE_PATH):
        st.error("No PageRank cache file available")
        return None
    data = load_json(PAGERANK_CACHE_PATH)
    df = pd.DataFrame(data)
    if "ID" not in df.columns or "influence_score" not in df.columns:
        st.error(
            "PageRank cache JSON must contain 'ID' and 'influence_score' "
            "fields for each entry."
        )
        return None
    return df


def trigger_external_pagerank_job() -> Tuple[int, str, str]:
    cmd = [sys.executable, "run_pagerank_job.py", "--output", PAGERANK_CACHE_PATH]
    try:
        proc = subprocess.run(
            cmd,
            check=False,
            capture_output=True,
            text=True,
        )
        return proc.returncode, proc.stdout, proc.stderr
    except FileNotFoundError:
        return 1, "", "run_pagerank_job.py not found"


def build_pagerank_cache() -> pd.DataFrame:
    pr_scores_df = load_pr_cache()
    if pr_scores_df is None or pr_scores_df.empty:
        st.error("No PageRank cache available.")
        return pd.DataFrame()
    pr_scores_df = pr_scores_df.sort_values(
        "influence_score", ascending=False
    ).reset_index(drop=True)
    return pr_scores_df


# === ALS Recommendations ===

def load_als_cache() -> pd.DataFrame | None:
    if not os.path.exists(ALS_CACHE_PATH):
        st.error("No ALS Recommendation cache file available")
        return None
    df = pd.read_json(ALS_CACHE_PATH, orient="records")
    if "userId" not in df.columns or "recommendations" not in df.columns:
        st.error(
            "ALS cache JSON must contain 'userId' and 'recommendations' "
            "fields for each entry."
        )
        return None
    return df


def trigger_external_als_job() -> Tuple[int, str, str]:
    cmd = [sys.executable, "run_alsrecs_job.py", "--output", ALS_CACHE_PATH]
    try:
        proc = subprocess.run(
            cmd,
            check=False,
            capture_output=True,
            text=True,
        )
        return proc.returncode, proc.stdout, proc.stderr
    except FileNotFoundError:
        return 1, "", "run_alsrecs_job.py not found"


def build_als_cache() -> pd.DataFrame:
    als_scores_df = load_als_cache()
    if als_scores_df is None or als_scores_df.empty:
        st.error("No ALS cache available.")
        return pd.DataFrame()
    return als_scores_df
    
    


# Network Agg helpers (Spark + GraphFrames)
def load_networkstats_cache()-> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame,] | None:
    """
    Load cached network statistics from JSON files produced by run_netagg_job.py.
    Returns 7 DataFrames:
      out_dist_df, in_dist_df, top_out_df, top_in_df,
      cat_stats_df, size_stats_df, view_stats_df
    """

    missing = []
    if not os.path.exists(DEGREE_CACHE_PATH):
        missing.append("degree stats")
    if not os.path.exists(CATEGORY_CACHE_PATH):
        missing.append("category stats")
    if not os.path.exists(SIZE_CACHE_PATH):
        missing.append("video size buckets")
    if not os.path.exists(VIEW_CACHE_PATH):
        missing.append("view count stats")

    if missing:
        st.error(
            "Missing network statistics cache file(s): "
            + ", ".join(missing)
            + ". Run the Network Statistics Phase 1 job to create them."
        )
        return None

    # Degree stats file is expected to be a JSON object with multiple lists
    with open(DEGREE_CACHE_PATH, "r", encoding="utf-8") as f:
        degree_stats = json.load(f)

    out_dist_df = pd.DataFrame(degree_stats.get("out_degree_distribution", []))
    in_dist_df = pd.DataFrame(degree_stats.get("in_degree_distribution", []))
    top_out_df = pd.DataFrame(degree_stats.get("top_by_out_degree", []))
    top_in_df = pd.DataFrame(degree_stats.get("top_by_in_degree", []))

    # Category stats – JSON array of records
    with open(CATEGORY_CACHE_PATH, "r", encoding="utf-8") as f:
        cat_stats = json.load(f)
    cat_stats_df = pd.DataFrame(cat_stats)

    # Size stats – JSON array of records
    with open(SIZE_CACHE_PATH, "r", encoding="utf-8") as f:
        size_stats = json.load(f)
    size_stats_df = pd.DataFrame(size_stats)

    # View stats – JSON array of records
    with open(VIEW_CACHE_PATH, "r", encoding="utf-8") as f:
        view_stats = json.load(f)
    view_stats_df = pd.DataFrame(view_stats)

    return (out_dist_df, in_dist_df, top_out_df, top_in_df, cat_stats_df, size_stats_df, view_stats_df)
    
def trigger_external_networkstats_job() -> Tuple[int, str, str]:
    cmd = [sys.executable, "run_netagg_job.py", "--output", DEGREE_CACHE_PATH]
    try:
        proc = subprocess.run(
            cmd,
            check=False,
            capture_output=True,
            text=True,
        )
        return proc.returncode, proc.stdout, proc.stderr
    except FileNotFoundError:
        return 1, "", "run_netagg_job.py not found"
        
def build_networkstats_caches() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    cached = load_networkstats_cache()
    if cached is None:
        return (pd.DataFrame(),) * 7
    return cached

def init_network_env():
    """
    Build Spark session, load the videos DataFrame, and build the GraphFrame.
    Store everything in st.session_state for reuse.
    Uses your functions from YoutubeNetworkAgg_Final.py.
    """
    spark = netagg.build_spark_session()
    df = netagg.load_videos_df(spark)
    #graph = netagg.build_graph(df)

    st.session_state["net_spark"] = spark
    st.session_state["net_df"] = df
    #st.session_state["net_graph"] = graph

    return df



def net_frequency_search(df, category, min_len, max_len, min_views):
    conds = []
    if category:
        conds.append(F.col("category") == category)
    if min_len is not None:
        conds.append(F.col("length") >= min_len)
    if max_len is not None:
        conds.append(F.col("length") <= max_len)
    if min_views is not None:
        conds.append(F.col("views") >= min_views)

    if conds:
        from functools import reduce as _reduce
        condition = _reduce(lambda a, b: a & b, conds)
        filtered = df.where(condition)
    else:
        filtered = df

    total = df.count()
    hits = filtered.count()

    if hits > 0:
        table = (
            filtered.select("id", "category", "views", "length")
            .orderBy(F.desc("views"))
            .limit(200)
            .toPandas()
        )
    else:
        table = pd.DataFrame(columns=["id", "category", "views", "length"])

    return total, hits, table

# =============================================================================
# streamlit GUI
# =============================================================================

def main() -> None:
    #st.set_page_config(page_title="EverCougs YouTube Analyzer", layout="wide")
    st.title("EverCougs YouTube Analyzer")

    st.markdown(
        """
        This app runs various algorithms on a database containing information about videos on YouTube collected in 2007–2008.

        It uses a two-phase architecture:

        **Phase 1** (sidebar):
        - Interacts with the database or external jobs to precompute expensive tasks.
        - For PageRank, results are cached in JSON and read in Phase 2.
        - For ALS recommendations, results are cached in JSON and read in Phase 2.
        - For network analytics, Phase 1 initializes Spark, loads MongoDB, and builds the GraphFrames graph.

        **Phase 2** (main area):
        - Lets you explore PageRank results, ALS recommendations,
          MongoDB queries, or run network statistics interactively.
        """
    )
    
    # =========================================================================
    # Phase 1 GUI (sidebar)
    # =========================================================================
    st.sidebar.header("Phase 1")

    # --- PageRank Phase 1 controls ---
    st.sidebar.subheader("PageRank cache")
    pr_phase1_mode = st.sidebar.radio(
        "Pagerank Phase 1 Mode",
        options=["Use existing Pagerank cache", "Trigger PageRank job now"],
        index=0,
    )

    # --- ALS Phase 1 controls ---
    st.sidebar.subheader("ALS Recommendations")
    als_phase1_mode = st.sidebar.radio(
        "ALS Phase 1 Mode",
        options=["Use existing ALS cache", "Trigger ALS job now"],
        index=0,
    )

    # --- NetworkStats Phase 1 controls ---
    st.sidebar.subheader("Network Statistics cache")
    ns_phase1_mode = st.sidebar.radio(
        "Network Stats Phase 1 Mode",
        options=["Use existing Network Statistics cache", "Trigger Network Stats job now"],
        index=0,
    )
    
    if st.sidebar.button("Run Phase 1 actions"):
        with st.spinner("Running Phase 1 actions..."):

            # PageRank
            if pr_phase1_mode == "Trigger PageRank job now":
                st.write("Triggering external PageRank job...")
                rc, out, err = trigger_external_pagerank_job()
                if rc != 0:
                    st.error(
                        "PageRank job failed. See logs below. "
                        "Phase 1 will not update the PR cache."
                    )
                    st.code(f"Return code: {rc}\n\nSTDOUT:\n{out}\n\nSTDERR:\n{err}")
                else:
                    st.success("PageRank job completed successfully. Cache updated.")
            else:
                st.write("Using existing PR cache (if available).")

            st.write("Rebuilding in-memory pagerank data...")
            pagerank_cache = build_pagerank_cache()
            st.session_state["pagerank_cache"] = pagerank_cache
            st.success("PageRank cache updated in session.")
                      
            # ALS
            if als_phase1_mode == "Trigger ALS job now":
                st.write("Triggering external ALS Recommendation job...")
                rc, out, err = trigger_external_als_job()
                if rc != 0:
                    st.error(
                        "ALS job failed. See logs below. "
                        "Phase 1 will not update the ALS cache."
                    )
                    st.code(f"Return code: {rc}\n\nSTDOUT:\n{out}\n\nSTDERR:\n{err}")
                else:
                    st.success("ALS job completed successfully. Cache updated.")
            else:
                st.write("Using existing ALS cache (if available).")

            st.write("Rebuilding in-memory ALS data...")
            als_cache = build_als_cache()
            st.session_state["als_cache"] = als_cache
            st.success("ALS recommendations cache updated in session.")
            
            # NetworkStats
            if ns_phase1_mode == "Trigger Network Stats job now":
                st.write("Triggering external NetworkStats job...")
                rc, out, err = trigger_external_networkstats_job()
                if rc != 0:
                    st.error(
                        "NetworkStats job failed. See logs below. "
                        "Phase 1 will not update the NS cache."
                    )
                    st.code(f"Return code: {rc}\n\nSTDOUT:\n{out}\n\nSTDERR:\n{err}")
                else:
                    st.success("NetworkStats job completed successfully. Cache updated.")
            else:
                st.write("Using existing Network Stats cache (if available).")

            st.write("Rebuilding in-memory NetworkStats data...")
            out_dist_cache, in_dist_cache, top_out_cache, top_in_cache, categorystats_cache, sizestats_cache, viewstats_cache = build_networkstats_caches()
            
            st.session_state["out_dist_cache"] = out_dist_cache
            st.session_state["in_dist_cache"] = in_dist_cache
            st.session_state["top_out_cache"] = top_out_cache
            st.session_state["top_in_cache"] = top_in_cache
            st.session_state["categorystats_cache"] = categorystats_cache
            st.session_state["sizestats_cache"] = sizestats_cache
            st.session_state["viewstats_cache"] = viewstats_cache
            st.success("NetworkStats cache updated in session.")
            
            df = init_network_env()

       
    st.sidebar.markdown("---")

    # =========================================================================
    # Phase 2 GUI
    # =========================================================================

    st.header("Phase 2")

    operation = st.selectbox(
        "Select which operation to perform:",
        (
            "Pagerank",
            "ALS Recommendations",
            "Query Videos by Category/Duration",
            "Query Videos by Views",
            "Top-K Views",
            "Network statistics",
        ),
        index=0,
    )

    st.write(f"You selected: **{operation}**")
    result_df = None

    # -------------------------------------------------------------------------
    # Operation: Pagerank
    # -------------------------------------------------------------------------
    if operation == "Pagerank":
        pagerank_cache: pd.DataFrame = st.session_state.get(
            "pagerank_cache", pd.DataFrame()
        )

        if pagerank_cache is None or pagerank_cache.empty:
            st.warning(
                "No pagerank cache found in session or cache is empty. "
                "Run the PageRank Phase 1 operation from the sidebar to build or reload it."
            )
            return

        k = st.number_input("Number of results to show", 1, 500, 10, 1)
        result_df = pagerank_cache.head(k)

    # -------------------------------------------------------------------------
    # Operation: ALS Recommendations
    # -------------------------------------------------------------------------
    elif operation == "ALS Recommendations":
        als_cache: pd.DataFrame = st.session_state.get("als_cache", pd.DataFrame())
        if als_cache.empty:
            st.error("ALS Recommendation cache is empty. Run Phase 1 again.")
        else:
            st.info("Displaying cached recommendations (entire ALS cache).")
            result_df = als_cache

    # -------------------------------------------------------------------------
    # Operation: Query Videos by Category/Duration (Mongo)
    # -------------------------------------------------------------------------
    elif operation == "Query Videos by Category/Duration":
        collection = get_mongo_collection()
        if collection is None:
            st.error("MongoDB connection not available.")
        else:
            with st.form("category_query_form"):
                category = st.text_input("Enter category name:").strip()
                t1 = st.number_input(
                    "Enter minimum duration (in seconds):", min_value=0, value=0
                )
                t2 = st.number_input(
                    "Enter maximum duration (in seconds):", min_value=0, value=600
                )
                submitted = st.form_submit_button("Run Query")

            if submitted:
                with st.spinner("Querying MongoDB..."):
                    query_length = {
                        "category": category,
                        "length": {"$gte": t1, "$lte": t2},
                    }
                    results = list(collection.find(query_length))
                    if not results:
                        st.warning("No matching videos found.")
                        result_df = pd.DataFrame()
                    else:
                        result_df = pd.DataFrame(results)
                        if "video_id" in result_df.columns:
                            result_df = result_df.rename(columns={"video_id": "ID"})
                        st.success(f"Found {len(result_df)} videos.")

    # -------------------------------------------------------------------------
    # Operation: Query Videos by Views (Mongo)
    # -------------------------------------------------------------------------
    elif operation == "Query Videos by Views":
        collection = get_mongo_collection()
        if collection is None:
            st.error("MongoDB connection not available.")
        else:
            with st.form("views_query_form"):
                x = st.number_input(
                    "Enter minimum number of views:", min_value=0, value=1000
                )
                y = st.number_input(
                    "Enter maximum number of views:", min_value=0, value=100000
                )
                submitted = st.form_submit_button("Run Query")

            if submitted:
                with st.spinner("Querying MongoDB..."):
                    query_views = {"views": {"$gte": x, "$lte": y}}
                    results = list(collection.find(query_views))
                    if not results:
                        st.warning("No matching videos found.")
                        result_df = pd.DataFrame()
                    else:
                        result_df = pd.DataFrame(results)
                        if "video_id" in result_df.columns:
                            result_df = result_df.rename(columns={"video_id": "ID"})
                        st.success(f"Found {len(result_df)} videos.")

    # -------------------------------------------------------------------------
    # Operation: Top-K Views (Mongo aggregation)
    # -------------------------------------------------------------------------
    elif operation == "Top-K Views":
        collection = get_mongo_collection()
        if collection is None:
            st.error("MongoDB connection not available.")
        else:
            K = st.number_input(
                "Enter K (Top how many videos?):", min_value=1, max_value=100, value=10
            )

            pipeline = [
                {"$sort": {"views": -1}},            # sort videos by views descending
                {"$limit": int(K)},                  # take top K
                {"$project": {                       # choose what you want in the table
                    "_id": 1,
                    "views": 1,
                    "uploader": 1,
                    "category": 1,
                    "length": 1,
                    "rate": 1,
                }},
            ]
            
            with st.spinner("Querying MongoDB..."):
                results = list(collection.aggregate(pipeline))

            if not results:
                st.warning("No videos found.")
                result_df = pd.DataFrame()
            else:
                result_df = pd.DataFrame(results)
                result_df.rename(columns={"_id": "ID"}, inplace=True)
                st.success(f"Found Top {len(result_df)} videos by views!")

    # -------------------------------------------------------------------------
    # Operation: Network statistics (Spark + GraphFrames)
    # -------------------------------------------------------------------------
    elif operation == "Network statistics":       
        st.subheader("Network statistics")

        net_op = st.selectbox(
            "Choose a network statistics operation:",
            (
                "Degree statistics",
                "Categorized statistics",
                "Video size buckets",
                "View count statistics",
                "Frequency by search condition",
            ),
            index=0,
        )

        # Degree statistics
        if net_op == "Degree statistics":            
            out_dist_cache: pd.DataFrame = st.session_state.get("out_dist_cache", pd.DataFrame())
            in_dist_cache: pd.DataFrame = st.session_state.get("in_dist_cache", pd.DataFrame())
            top_out_cache: pd.DataFrame = st.session_state.get("top_out_cache", pd.DataFrame())
            top_in_cache: pd.DataFrame = st.session_state.get("top_in_cache", pd.DataFrame())
            
            if (out_dist_cache.empty and in_dist_cache.empty and top_out_cache.empty and top_in_cache.empty):
                st.warning("Network degree statistics cache is empty. Run the Network Statistics Phase 1 job from the sidebar." )
                return

            tab1, tab2, tab3, tab4 = st.tabs(
                [
                    "Out-degree distribution",
                    "In-degree distribution",
                    "Top by out-degree",
                    "Top by in-degree",
                ]
            )
            
            with tab1:
                st.dataframe(out_dist_cache)
            with tab2:
                st.dataframe(in_dist_cache)
            with tab3:
                st.dataframe(top_out_cache)
            with tab4:
                st.dataframe(top_in_cache)

            return  # end Degree statistics branch

        # Categorized statistics
        elif net_op == "Categorized statistics":
            categorystats_cache: pd.DataFrame = st.session_state.get(
                "categorystats_cache", pd.DataFrame()
            )
            if categorystats_cache.empty:
                st.warning(
                    "Category statistics cache is empty. "
                    "Run the Network Statistics Phase 1 job from the sidebar."
                )
                return

            st.markdown("### Category-level statistics")
            st.dataframe(categorystats_cache)
            return

        # Video size buckets
        elif net_op == "Video size buckets":
            sizestats_cache: pd.DataFrame = st.session_state.get(
                "sizestats_cache", pd.DataFrame()
            )
            if sizestats_cache.empty:
                st.warning(
                    "Video size bucket statistics cache is empty. "
                    "Run the Network Statistics Phase 1 job from the sidebar."
                )
                return

            st.markdown("### Video size bucket statistics")
            st.dataframe(sizestats_cache)
            return

        # View count statistics
        elif net_op == "View count statistics":
            viewstats_cache: pd.DataFrame = st.session_state.get(
                "viewstats_cache", pd.DataFrame()
            )
            if viewstats_cache.empty:
                st.warning(
                    "View count statistics cache is empty. "
                    "Run the Network Statistics Phase 1 job from the sidebar."
                )
                return

            st.markdown("### View count statistics")
            st.dataframe(viewstats_cache)
            return

        # Frequency by search condition
        elif net_op == "Frequency by search condition":                     
            df = st.session_state.get("net_df")
            if df is None:
                st.warning(
                    "Network Spark environment is not initialized yet.\n\n"
                    "Run the Network Statistics Phase 1 job, or click the "
                    "button below to initialize it now."
                )
                if st.button("Initialize / refresh network environment now"):
                    with st.spinner("Initializing Spark and loading videos DataFrame..."):
                        df = init_network_env()
                if df is None:
                    return  # still not available

            st.markdown(
                """
                Filter the videos by category, length, and minimum views.
                Leave a field blank (or 0 for numerics) to ignore that filter.
                """
            )

            category = st.text_input(
                "Category (exact name, blank for ALL):", value=""
            )

            col1, col2, col3 = st.columns(3)
            with col1:
                min_len = st.number_input(
                    "Minimum length (seconds, 0 = none):", min_value=0, value=0
                )
            with col2:
                max_len = st.number_input(
                    "Maximum length (seconds, 0 = none):", min_value=0, value=0
                )
            with col3:
                min_views = st.number_input(
                    "Minimum views (0 = none):", min_value=0, value=0
                )

            min_len_val = min_len if min_len > 0 else None
            max_len_val = max_len if max_len > 0 else None
            min_views_val = min_views if min_views > 0 else None

            if st.button("Run search"):
                with st.spinner("Running search..."):
                    total, hits, table_pdf = net_frequency_search(
                        df,
                        category.strip(),
                        min_len_val,
                        max_len_val,
                        min_views_val,
                    )

                st.write(f"Total videos: {total:,}")
                st.write(f"Matching videos: {hits:,}")

                if hits > 0:
                    st.markdown("#### Matching videos (top 200 by views)")
                    st.dataframe(table_pdf)
                else:
                    st.info("No videos matched the specified filters.")

            return  # end Frequency branch

    # -------------------------------------------------------------------------
    # After all non-network operations: validate and show result_df
    # -------------------------------------------------------------------------
    if result_df is None:
        st.error("No operation performed.")
        st.stop()
    if result_df.empty:
        st.error("No rows to display.")
        st.stop()

    st.subheader("Operation results")
    st.dataframe(result_df)

    # Video playback support (if ID column present)
    if "ID" not in result_df.columns:
        st.warning("Result dataframe does not contain 'ID'. Unable to handle video playback as normal. Manaul Search is available:")
        manual_id = st.text_input("Paste a YouTube video ID (the part after v= in the URL):", key="manual_video_id")

        if st.button("Play video by ID"):
            if manual_id.strip():
                open_video(manual_id.strip())
            else:
                st.error("Please enter a valid video ID before clicking play.")
    
    else:
        selected_ID = st.selectbox(
            "Choose a video to play from these results:",
            result_df["ID"].tolist(),
        )
        selected_row = result_df.loc[result_df["ID"] == selected_ID].iloc[0]
        selected_id = selected_row["ID"]
        if st.button("Play selected video"):
            open_video(selected_id)


if __name__ == "__main__":
    main()


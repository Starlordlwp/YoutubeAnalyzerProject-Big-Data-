from pyspark.sql import SparkSession
from pyspark.ml.recommendation import ALS
from pyspark.sql.functions import col
from pyspark.sql.types import IntegerType

def main():

    spark = (
        SparkSession.builder
        .appName("YouTubeVideoRecommendation")
        .config("spark.jars.packages", "org.mongodb.spark:mongo-spark-connector_2.12:10.5.0")
        .config("spark.mongodb.connection.uri", "mongodb://localhost:27017")
        .config("spark.driver.memory", "8g")
        .config("spark.executor.memory", "8g")
        .config("spark.driver.maxResultSize", "4g")
        .getOrCreate()
    )
    

    # 2. Load your EXISTING data from MongoDB
    # ----------------------------------------------------------
    videos_df = spark.read.format("mongodb").option("database", "415_YoutubeGroupDB").option("collection", "videos").load()

    print("Loaded videos from MongoDB.")
    videos_df.printSchema()

   #3 prep dataset
    # numeric IDs for ALS
    from pyspark.ml.feature import StringIndexer

    user_indexer = StringIndexer(inputCol="uploader", outputCol="userId")
    video_indexer = StringIndexer(inputCol="_id", outputCol="videoId")

    videos_indexed = user_indexer.fit(videos_df).transform(videos_df)
    videos_indexed = video_indexer.fit(videos_indexed).transform(videos_indexed)

    # ALS expects "rating" column;use 'rate' from dataset
    als_df = videos_indexed.select(
        col("userId").cast(IntegerType()),
        col("videoId").cast(IntegerType()),
        col("rate").alias("rating")
    ).na.drop()

    print("Prepared data for ALS.")
    als_df.show(5, truncate=False)

    # ----------------------------------------------------------
    # 4. Train ALS model
    # ----------------------------------------------------------
    als = ALS(
        maxIter=10,
        regParam=0.1,
        userCol="userId",
        itemCol="videoId",
        ratingCol="rating",
        coldStartStrategy="drop"
    )

    model = als.fit(als_df)
    print("ALS model trained.\n")

    # ----------------------------------------------------------
    # 5. Make recommendations for all users
    # ----------------------------------------------------------
    #
    # user_recs = model.recommendForAllUsers(5)  # top 5 video recommendations per uploader

    user_subset = als_df.select("userId").distinct().limit(20)

    user_recs = model.recommendForUserSubset(user_subset, 5)
    print("Sample recommendations:")
    
    user_recs.show(truncate=False)

    print(f"Saving recommendations to {ALS_CACHE_PATH}...")
    
    # Convert recommendations to Pandas DataFrame for easy JSON export
    user_recs_pandas = user_recs.toPandas()
    
    # The 'recommendations' column contains Row objects. Convert them to simple lists.
    user_recs_pandas['recommendations'] = user_recs_pandas['recommendations'].apply(
        lambda recs: [rec.videoId for rec in recs]
    )
    
    # Save as JSON
    user_recs_pandas.to_json(ALS_CACHE_PATH, orient="records")
    
    print("Save complete.")

    spark.stop()


if __name__ == "__main__":
    main()